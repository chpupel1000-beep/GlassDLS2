package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Ускоряет бег. Для одиночной игры и своего сервера. */
public class Speed extends Module {
    private static final String[] NAMES = {"x1.3", "x1.6", "x2.0", "x3.0"};
    private static final double[] MULT = {1.3, 1.6, 2.0, 3.0};
    private final Setting boost = addSetting("Boost", NAMES, 1);

    public Speed() {
        super("Speed", "Быстрее бегаешь", Category.MOVEMENT);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || p.hasVehicle() || p.isFallFlying() || p.getAbilities().flying
                || p.isTouchingWater() || p.isClimbing()) return;
        double fwd = p.input.movementForward, side = p.input.movementSideways;
        if (fwd == 0 && side == 0) return;
        double len = Math.sqrt(fwd * fwd + side * side);
        if (len > 1.0) { fwd /= len; side /= len; }
        double yaw = Math.toRadians(p.getYaw());
        double base = (p.isSprinting() ? 0.28 : 0.215) * MULT[boost.index];
        double vx = (side * Math.cos(yaw) - fwd * Math.sin(yaw)) * base;
        double vz = (fwd * Math.cos(yaw) + side * Math.sin(yaw)) * base;
        p.setVelocity(vx, p.getVelocity().y, vz);
    }
}
