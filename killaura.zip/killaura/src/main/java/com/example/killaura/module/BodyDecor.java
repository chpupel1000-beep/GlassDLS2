package com.example.killaura.module;

import com.example.killaura.Palette;
import com.example.killaura.WorldDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Основа для украшений на спине (плащ, крылья): рисуются только на тебе и только когда камера сзади. */
abstract class BodyDecor extends Module {
    protected final Setting color = addSetting("Color", Palette.NAMES, 0);
    protected final Setting size;
    private long lastTick = System.nanoTime();
    private double smoothSpeed, smoothFall;
    /** 0 = стоим, 1 = бежим на полной скорости или падаем: насколько ткань развевается. */
    protected double motion;

    protected BodyDecor(String name, String description, String[] sizeNames, int sizeDefault) {
        super(name, description, Category.VISUALS);
        size = addSetting("Size", sizeNames, sizeDefault);
    }

    @Override
    public void onTick(MinecraftClient client) {
        lastTick = System.nanoTime();
    }

    /** pos = ноги, left = влево от игрока, back = назад от игрока. */
    protected abstract void draw(DrawContext c, WorldDraw cam, Vec3d pos, Vec3d left, Vec3d back, int rgb);

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity p = client.player;
        if (p == null || client.world == null) return;
        if (client.options.getPerspective().isFirstPerson()) return;

        double t = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        double x = p.prevX + (p.getX() - p.prevX) * t;
        double y = p.prevY + (p.getY() - p.prevY) * t;
        double z = p.prevZ + (p.getZ() - p.prevZ) * t;
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees((float) t, p.prevBodyYaw, p.bodyYaw));
        Vec3d back = new Vec3d(Math.sin(yaw), 0.0, -Math.cos(yaw));
        Vec3d left = new Vec3d(Math.cos(yaw), 0.0, Math.sin(yaw));
        Vec3d pos = new Vec3d(x, y, z);

        // Плавная скорость: от неё зависит, как сильно развевается ткань
        double raw = Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ);
        smoothSpeed += (raw - smoothSpeed) * 0.12;
        smoothFall += ((p.getY() - p.prevY) - smoothFall) * 0.12;
        motion = Math.max(Math.min(1.0, smoothSpeed / 0.26), Math.max(0.0, Math.min(1.0, -smoothFall / 0.5)));

        WorldDraw cam = new WorldDraw(client, c);
        // Если камера спереди, украшение закрыто телом, поэтому не рисуем
        if (cam.camPos.subtract(pos).dotProduct(back) <= 0) return;
        draw(c, cam, pos, left, back, Palette.RGB[color.index]);
    }
}
