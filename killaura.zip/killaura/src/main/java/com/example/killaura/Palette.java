package com.example.killaura;

/** Общий набор цветов для настроек Color. */
public final class Palette {
    public static final String[] NAMES =
            {"Ice", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink", "White", "Black"};
    public static final int[] RGB =
            {0x7DD3FC, 0xEF4444, 0xF97316, 0xFACC15, 0x22C55E, 0x06B6D4, 0x3B82F6, 0xA855F7, 0xEC4899, 0xF8FAFC, 0x111827};

    private Palette() {}

    public static int shade(int rgb, double k) {
        int r = (int) (((rgb >> 16) & 0xFF) * k);
        int g = (int) (((rgb >> 8) & 0xFF) * k);
        int b = (int) ((rgb & 0xFF) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
