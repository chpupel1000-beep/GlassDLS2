package com.example.killaura.module;

import com.example.killaura.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;

/** Показывает, какие клавиши (WASD, пробел) и кнопки мыши нажаты. */
public class Keystrokes extends Module {
    public Keystrokes() {
        super("Keystrokes", "WASD, пробел и кнопки мыши на экране", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int x = HudLayout.x(HudLayout.KEYS, c.getScaledWindowWidth(), HudLayout.KEYS.w);
        int y = HudLayout.y(HudLayout.KEYS, c.getScaledWindowHeight(), HudLayout.KEYS.h);
        var o = client.options;
        key(c, client, o.forwardKey, x + 22, y, 20, 20);
        key(c, client, o.leftKey, x, y + 22, 20, 20);
        key(c, client, o.backKey, x + 22, y + 22, 20, 20);
        key(c, client, o.rightKey, x + 44, y + 22, 20, 20);
        box(c, client, "LMB", o.attackKey.isPressed(), x, y + 44, 31, 16);
        box(c, client, "RMB", o.useKey.isPressed(), x + 33, y + 44, 31, 16);
        box(c, client, "___", o.jumpKey.isPressed(), x, y + 62, 64, 10);
    }

    private void key(DrawContext c, MinecraftClient client, KeyBinding kb, int x, int y, int w, int h) {
        box(c, client, kb.getBoundKeyLocalizedText().getString(), kb.isPressed(), x, y, w, h);
    }

    private void box(DrawContext c, MinecraftClient client, String label, boolean down, int x, int y, int w, int h) {
        c.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x66101826);
        int tw = client.textRenderer.getWidth(label);
        if (h >= 14) {
            c.drawText(client.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2,
                    down ? 0xFF101826 : 0xFFF1F5F9, false);
        }
    }
}
