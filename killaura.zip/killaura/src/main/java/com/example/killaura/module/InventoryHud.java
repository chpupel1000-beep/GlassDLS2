package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;

/** Показывает содержимое рюкзака (3 ряда по 9 ячеек) прямо на экране. */
public class InventoryHud extends Module {
    private static final int ACCENT = 0xFF7DD3FC;

    public InventoryHud() {
        super("Inventory", "Содержимое инвентаря на экране", Category.MISC);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.currentScreen instanceof HandledScreen<?>) return;

        int pw = 9 * 18 + 8;
        int ph = 3 * 18 + 8;
        int x = 4;
        int y = c.getScaledWindowHeight() / 2 - ph / 2;

        c.fill(x, y, x + pw, y + ph, 0x66101826);
        c.fill(x, y, x + pw, y + 1, ACCENT);

        for (int i = 0; i < 27; i++) {
            int sx = x + 4 + (i % 9) * 18 + 1;
            int sy = y + 4 + (i / 9) * 18 + 1;
            c.fill(sx, sy, sx + 16, sy + 16, 0x22FFFFFF);
            ItemStack stack = client.player.getInventory().getStack(9 + i);
            if (!stack.isEmpty()) {
                c.drawItem(stack, sx, sy);
                c.drawStackOverlay(client.textRenderer, stack, sx, sy);
            }
        }
    }
}
