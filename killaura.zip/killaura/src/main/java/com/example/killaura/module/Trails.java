package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.List;

/** Красивый след из частиц за тобой, когда двигаешься. */
public class Trails extends Module {
    private static final String[] NAMES = {"End Rod", "Flame", "Hearts", "Soul Fire", "Notes", "Magic", "Cloud", "Enchant"};
    private static final ParticleEffect[] TYPES = {
            ParticleTypes.END_ROD, ParticleTypes.FLAME, ParticleTypes.HEART, ParticleTypes.SOUL_FIRE_FLAME,
            ParticleTypes.NOTE, ParticleTypes.HAPPY_VILLAGER, ParticleTypes.CLOUD, ParticleTypes.ENCHANT
    };

    public Trails() {
        super("Trails", "След из частиц за тобой (мешает NoRender Particles)", Category.VISUALS);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || client.world == null) return;
        double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ, dy = p.getY() - p.prevY;
        if (dx * dx + dz * dz + dy * dy < 0.0004) return; // стоим на месте
        ParticleEffect type = TYPES[Math.max(0, Math.min(mode, TYPES.length - 1))];
        for (int i = 0; i < 2; i++) {
            double ox = (Math.random() - 0.5) * 0.4, oz = (Math.random() - 0.5) * 0.4;
            client.world.addParticle(type, p.getX() + ox, p.getY() + 0.1 + Math.random() * 0.3, p.getZ() + oz, 0.0, 0.0, 0.0);
        }
    }
}
