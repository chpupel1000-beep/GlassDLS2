package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

public class ESPPlayers extends Module {
    public ESPPlayers() {
        super("ESPPlayers", "Подсвечивает других игроков сквозь стены", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null) return;
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p != client.player) p.setGlowing(true);
        }
    }

    @Override
    public void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;
        for (PlayerEntity p : client.world.getPlayers()) {
            if (p != client.player) p.setGlowing(false);
        }
    }
}
