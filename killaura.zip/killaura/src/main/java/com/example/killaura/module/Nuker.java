package com.example.killaura.module;

import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Ломает ближайшие блоки вокруг. Для креатива, строительства и своего мира. */
public class Nuker extends Module {
    private final Setting radius = addSetting("Radius", new String[]{"2", "3", "4"}, 1);

    public Nuker() {
        super("Nuker", "Ломает ближайшие блоки вокруг тебя", Category.PLAYER);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || client.world == null || client.interactionManager == null || client.currentScreen != null) return;
        int r = Integer.parseInt(radius.value());
        BlockPos origin = p.getBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    double d = pos.toCenterPos().squaredDistanceTo(p.getEyePos());
                    if (d > r * r + 1.0 || d >= bestD) continue;
                    BlockState st = client.world.getBlockState(pos);
                    if (st.isAir() || st.getBlock() instanceof FluidBlock) continue;
                    if (st.getHardness(client.world, pos) < 0) continue;
                    best = pos;
                    bestD = d;
                }
            }
        }
        if (best != null) {
            client.interactionManager.updateBlockBreakingProgress(best, Direction.UP);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
