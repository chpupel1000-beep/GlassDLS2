package com.example.killaura;

import com.example.killaura.gui.ClickGuiScreen;
import com.example.killaura.gui.HudEditorScreen;
import com.example.killaura.module.Module;
import com.example.killaura.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KillAuraMod implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static KeyBinding menuKey;
    /** Ставится командой .hud, редактор открывается на следующем тике. */
    public static volatile boolean openHudEditor;

    @Override
    public void onInitializeClient() {
        MODULES.init();
        HudLayout.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.killaura.menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.killaura"));

        // Чат-команда .bind
        ClientSendMessageEvents.ALLOW_CHAT.register(BindCommand::handle);

        // Рисование модулей поверх игрового экрана (HUD, Arrows, Inventory)
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            for (Module m : MODULES.getModules()) {
                if (m.isEnabled()) m.renderHud(context);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        if (openHudEditor && client.currentScreen == null) {
            openHudEditor = false;
            client.setScreen(new HudEditorScreen(null));
        }
        while (menuKey.wasPressed()) {
            if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
        }
        MODULES.tick(client);
    }
}
