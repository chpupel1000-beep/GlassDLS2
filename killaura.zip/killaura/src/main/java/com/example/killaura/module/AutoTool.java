package com.example.killaura.module;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Когда копаешь блок, сам берёт из хотбара самый быстрый инструмент. */
public class AutoTool extends Module {
    public AutoTool() {
        super("AutoTool", "Сам берёт нужный инструмент при копании", Category.PLAYER);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || client.world == null || client.currentScreen != null) return;
        if (!client.options.attackKey.isPressed()) return;
        HitResult hit = client.crosshairTarget;
        if (!(hit instanceof BlockHitResult bhr) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockState state = client.world.getBlockState(bhr.getBlockPos());
        if (state.isAir()) return;

        int bestSlot = p.getInventory().selectedSlot;
        float best = p.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            float sp = s.getMiningSpeedMultiplier(state);
            if (sp > best + 0.01f) {
                best = sp;
                bestSlot = i;
            }
        }
        p.getInventory().selectedSlot = bestSlot;
    }
}
