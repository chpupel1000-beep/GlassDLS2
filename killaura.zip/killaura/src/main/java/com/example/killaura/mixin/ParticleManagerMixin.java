package com.example.killaura.mixin;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.NoRender;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {
    // NoRender (Particles): любая новая частица проходит через этот метод, не даём ей появиться
    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void glassdls$noParticles(CallbackInfo ci) {
        NoRender noRender = KillAuraMod.MODULES.get(NoRender.class);
        if (noRender != null && noRender.isEnabled() && noRender.noParticles()) ci.cancel();
    }
}
