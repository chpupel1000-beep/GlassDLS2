package com.example.killaura.mixin;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.SwingAnimation;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    // Длительность взмаха руки только у нашего игрока
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true, require = 0)
    private void glassdls$swingDuration(CallbackInfoReturnable<Integer> cir) {
        MinecraftClient client = MinecraftClient.getInstance();
        if ((Object) this != client.player) return;
        SwingAnimation swing = KillAuraMod.MODULES.getActiveSwing();
        if (swing != null) cir.setReturnValue(swing.duration());
    }
}
