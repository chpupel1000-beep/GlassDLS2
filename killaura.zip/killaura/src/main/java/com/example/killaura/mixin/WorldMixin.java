package com.example.killaura.mixin;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.TimeChanger;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public abstract class WorldMixin {
    private TimeChanger glassdls$active() {
        if (!((Object) this instanceof ClientWorld)) return null;
        TimeChanger t = KillAuraMod.MODULES.get(TimeChanger.class);
        return (t != null && t.isEnabled()) ? t : null;
    }

    @Inject(method = "getTimeOfDay", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassdls$time(CallbackInfoReturnable<Long> cir) {
        TimeChanger t = glassdls$active();
        if (t != null) cir.setReturnValue(t.time());
    }

    @Inject(method = "getSkyAngle", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassdls$sky(CallbackInfoReturnable<Float> cir) {
        TimeChanger t = glassdls$active();
        if (t != null) cir.setReturnValue(t.skyAngle());
    }
}
