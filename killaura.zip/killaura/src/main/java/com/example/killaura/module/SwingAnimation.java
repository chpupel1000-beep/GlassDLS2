package com.example.killaura.module;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.List;

/** Анимации удара мечом. Режим выбирается кнопкой на карточке в меню. */
public class SwingAnimation extends Module {
    private static final String[] NAMES = {"Slow", "Slash", "Stab", "Spin", "Smash", "Wobble"};
    // Длительность взмаха в тиках (в обычной игре 6)
    private static final int[] DURATION = {18, 10, 8, 12, 12, 14};

    public SwingAnimation() {
        super("SwingAnimation", "Анимации удара мечом", Category.VISUALS);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    private int index() { return Math.max(0, Math.min(mode, NAMES.length - 1)); }

    public int duration() { return DURATION[index()]; }

    /** Slow меняет только скорость, движение остаётся обычным. */
    public boolean customTransform() { return index() != 0; }

    /**
     * Движение предмета. p = прогресс взмаха от 0 до 1.
     * Во всех режимах при p = 0 и p = 1 предмет возвращается в обычное положение.
     */
    public void apply(MatrixStack m, Arm arm, float p) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        float pi = (float) Math.PI;
        float s = MathHelper.sin(p * pi);

        switch (index()) {
            case 1 -> { // Slash: широкий горизонтальный взмах справа налево
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 55.0f * MathHelper.sin(p * 2.0f * pi)));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -35.0f * s));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30.0f * s));
            }
            case 2 -> { // Stab: колющий выпад вперёд
                m.translate(0.0f, 0.0f, -0.55f * s);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-15.0f * s));
            }
            case 3 -> { // Spin: полный оборот
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-360.0f * p));
            }
            case 4 -> { // Smash: замах и рубящий удар сверху вниз
                float a;
                if (p < 0.35f) a = -50.0f * (p / 0.35f);
                else if (p < 0.7f) a = -50.0f + 110.0f * ((p - 0.35f) / 0.35f);
                else a = 60.0f * (1.0f - (p - 0.7f) / 0.3f);
                m.translate(0.0f, 0.15f * s, -0.1f * s);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(a));
            }
            case 5 -> { // Wobble: покачивание восьмёркой
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 30.0f * MathHelper.sin(p * 2.0f * pi)));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-25.0f * s));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 20.0f * MathHelper.sin(p * 4.0f * pi)));
            }
            default -> {}
        }
    }
}
