package com.example.killaura.module;

import com.example.killaura.Palette;
import com.example.killaura.WorldDraw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/**
 * Цветной плащ на спине (виден в виде от третьего лица, когда камера сзади).
 * Стоишь: плащ висит ровно. Бежишь или падаешь: плащ отлетает назад, поднимается и волнами колышется.
 */
public class Cape extends BodyDecor {
    private static final String[] SIZES = {"Short", "Medium", "Long"};
    private static final double[] LENGTHS = {0.8, 1.1, 1.4};

    public Cape() {
        super("Cape", "Плащ, который летит назад, когда бежишь (F5)", SIZES, 1);
    }

    @Override
    protected void draw(DrawContext c, WorldDraw cam, Vec3d pos, Vec3d left, Vec3d back, int rgb) {
        double top = 1.42;
        double len = LENGTHS[size.index];
        double half = 0.26;
        double m = motion;
        double time = System.nanoTime() / 1.0e9;
        int n = 8;
        Vec3d[] l = new Vec3d[n + 1], r = new Vec3d[n + 1];
        for (int i = 0; i <= n; i++) {
            double f = (double) i / n;
            // Вниз: при беге плащ поднимается и вытягивается назад
            double y = top - len * f * (1.0 - 0.6 * m);
            double bk = 0.14 + 0.10 * f * f + len * f * (0.9 * m);
            // Волна по ткани, сильнее к краю и на скорости
            double wave = Math.sin(time * 9.0 - f * 5.0) * 0.07 * f * m;
            double sway = Math.sin(time * 6.0 - f * 4.0) * 0.05 * f * m;
            double w = half * (1.0 + 0.25 * f);
            Vec3d centre = pos.add(0.0, y + wave, 0.0).add(back.multiply(bk)).add(left.multiply(sway));
            l[i] = centre.add(left.multiply(-w));
            r[i] = centre.add(left.multiply(w));
        }
        for (int i = 0; i < n; i++) {
            double f = (double) i / n;
            int col = Palette.shade(rgb, 1.0 - 0.3 * f - 0.1 * m * ((i % 2 == 0) ? 1 : 0));
            cam.tri(c, l[i], r[i], r[i + 1], col);
            cam.tri(c, l[i], r[i + 1], l[i + 1], col);
        }
    }
}
