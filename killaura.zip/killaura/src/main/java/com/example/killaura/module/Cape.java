package com.example.killaura.module;

import com.example.killaura.Palette;
import com.example.killaura.WorldDraw;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/** Цветной плащ на спине (виден в виде от третьего лица, когда камера сзади). */
public class Cape extends BodyDecor {
    private static final String[] SIZES = {"Short", "Medium", "Long"};
    private static final double[] LENGTHS = {0.8, 1.1, 1.4};

    public Cape() {
        super("Cape", "Цветной плащ на спине (F5)", SIZES, 1);
    }

    @Override
    protected void draw(DrawContext c, WorldDraw cam, Vec3d pos, Vec3d left, Vec3d back, int rgb) {
        double top = 1.42;
        double len = LENGTHS[size.index];
        double half = 0.26;
        int n = 6;
        for (int i = 0; i < n; i++) {
            double f0 = (double) i / n, f1 = (double) (i + 1) / n;
            Vec3d l0 = point(pos, left, back, top - len * f0, 0.16 + 0.25 * f0 * f0, -half * (1 + 0.2 * f0));
            Vec3d r0 = point(pos, left, back, top - len * f0, 0.16 + 0.25 * f0 * f0, half * (1 + 0.2 * f0));
            Vec3d l1 = point(pos, left, back, top - len * f1, 0.16 + 0.25 * f1 * f1, -half * (1 + 0.2 * f1));
            Vec3d r1 = point(pos, left, back, top - len * f1, 0.16 + 0.25 * f1 * f1, half * (1 + 0.2 * f1));
            int col = Palette.shade(rgb, 1.0 - 0.35 * f0);
            cam.tri(c, l0, r0, r1, col);
            cam.tri(c, l0, r1, l1, col);
        }
    }

    private static Vec3d point(Vec3d pos, Vec3d left, Vec3d back, double y, double backDist, double side) {
        return pos.add(0.0, y, 0.0).add(back.multiply(backDist)).add(left.multiply(side));
    }
}
