package com.example.killaura;

import net.minecraft.client.gui.DrawContext;

/** Мелкие помощники для рисования на экране. */
public final class HudDraw {
    private HudDraw() {}

    /** Заливка треугольника горизонтальными полосами. */
    public static void fillTriangle(DrawContext c, double x1, double y1, double x2, double y2,
                                    double x3, double y3, int color) {
        int minY = (int) Math.floor(Math.min(y1, Math.min(y2, y3)));
        int maxY = (int) Math.ceil(Math.max(y1, Math.max(y2, y3)));
        double[][] edges = {{x1, y1, x2, y2}, {x2, y2, x3, y3}, {x3, y3, x1, y1}};
        for (int y = minY; y <= maxY; y++) {
            double sy = y + 0.5;
            double left = Double.MAX_VALUE, right = -Double.MAX_VALUE;
            for (double[] e : edges) {
                double ya = e[1], yb = e[3];
                if (ya == yb || sy < Math.min(ya, yb) || sy > Math.max(ya, yb)) continue;
                double x = e[0] + (sy - ya) / (yb - ya) * (e[2] - e[0]);
                left = Math.min(left, x);
                right = Math.max(right, x);
            }
            if (left <= right) {
                int xl = (int) Math.floor(left);
                int xr = Math.max(xl + 1, (int) Math.ceil(right));
                c.fill(xl, y, xr, y + 1, color);
            }
        }
    }
}
