package com.example.killaura.module;

import java.util.List;

/** Меняет время суток только на твоём экране (сервер и другие игроки не затронуты). */
public class TimeChanger extends Module {
    private static final String[] NAMES = {"Day", "Noon", "Sunset", "Night", "Midnight", "Sunrise"};
    private static final long[] TIMES = {1000, 6000, 12500, 14000, 18000, 23000};

    public TimeChanger() {
        super("TimeChanger", "Время суток только у тебя на экране", Category.VISUALS);
        mode = 1;
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    public long time() { return TIMES[Math.max(0, Math.min(mode, TIMES.length - 1))]; }

    /** Угол неба для времени t (та же формула, что в игре). */
    public float skyAngle() {
        double d = (time() / 24000.0) - 0.25;
        d = d - Math.floor(d);
        double e = 0.5 - Math.cos(d * Math.PI) / 2.0;
        return (float) ((d * 2.0 + e) / 3.0);
    }
}
