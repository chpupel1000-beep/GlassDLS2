package com.example.killaura.module;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final Path bindFile = FabricLoader.getInstance().getConfigDir().resolve("glassdls-binds.properties");

    public void init() {
        // Добавить новый модуль = одна строка здесь
        register(new KillAura(), GLFW.GLFW_KEY_R);
        register(new Sprint(), GLFW.GLFW_KEY_UNKNOWN);
        register(new Fullbright(), GLFW.GLFW_KEY_UNKNOWN);
        register(new ESP(), GLFW.GLFW_KEY_UNKNOWN);
        register(new ESPPlayers(), GLFW.GLFW_KEY_UNKNOWN);
        register(new AuraPlayers(), GLFW.GLFW_KEY_UNKNOWN);
        register(new SwingAnimation(), GLFW.GLFW_KEY_UNKNOWN);
        load();
    }

    private void register(Module m, int defaultKey) {
        m.key = defaultKey;
        modules.add(m);
    }

    public List<Module> getModules() { return modules; }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) if (type.isInstance(m)) return (T) m;
        return null;
    }

    /** Включённая анимация удара или null. */
    public SwingAnimation getActiveSwing() {
        SwingAnimation s = get(SwingAnimation.class);
        return (s != null && s.isEnabled()) ? s : null;
    }

    /** Поиск модуля по имени без учёта регистра. */
    public Module find(String name) {
        for (Module m : modules) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    public void setKey(Module m, int key) {
        m.key = key;
        save();
    }

    public void tick(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        for (Module m : modules) {
            if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                boolean down = InputUtil.isKeyPressed(window, m.key);
                // Срабатывает только вне меню и чата, один раз на нажатие
                if (down && !m.keyDown && client.currentScreen == null) {
                    m.toggle();
                    if (client.player != null) {
                        client.player.sendMessage(Text.literal(
                                m.getName() + ": " + (m.isEnabled() ? "ON" : "OFF")), true);
                    }
                }
                m.keyDown = down;
            }
            if (m.isEnabled()) m.onTick(client);
        }
    }

    private void load() {
        if (!Files.exists(bindFile)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(bindFile)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : modules) {
            String v = p.getProperty(m.getName());
            if (v != null) {
                try { m.key = Integer.parseInt(v.trim()); } catch (NumberFormatException ignored) {}
            }
            String mv = p.getProperty(m.getName() + ".mode");
            if (mv != null) {
                try {
                    int idx = Integer.parseInt(mv.trim());
                    if (idx >= 0 && idx < m.getModes().size()) m.mode = idx;
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    /** Сохраняет привязки клавиш и выбранные режимы. */
    public void save() {
        Properties p = new Properties();
        for (Module m : modules) {
            p.setProperty(m.getName(), String.valueOf(m.key));
            if (!m.getModes().isEmpty()) p.setProperty(m.getName() + ".mode", String.valueOf(m.mode));
        }
        try (OutputStream out = Files.newOutputStream(bindFile)) {
            p.store(out, "glassDLS settings");
        } catch (IOException ignored) {}
    }
}
