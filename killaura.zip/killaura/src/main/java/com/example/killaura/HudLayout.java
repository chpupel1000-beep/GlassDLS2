package com.example.killaura;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Позиции элементов HUD. Хранятся как доли экрана (0..1), поэтому одинаково
 * работают на любом разрешении и масштабе интерфейса. Сохраняются в config.
 */
public final class HudLayout {
    public static final int INV_W = 9 * 18 + 8;
    public static final int INV_H = 3 * 18 + 8;
    public static final int TARGET_W = 124;
    public static final int TARGET_H = 36;

    public static final class Pos {
        public final String id;
        private final float defX, defY;
        public float fx, fy;

        Pos(String id, float defX, float defY) {
            this.id = id;
            this.defX = defX;
            this.defY = defY;
            reset();
        }

        public void reset() { fx = defX; fy = defY; }
    }

    // Для Inventory и TargetESP (fx, fy) = положение левого верхнего угла,
    // для Arrows = положение центра круга.
    public static final Pos INVENTORY = new Pos("inventory", 0.0f, 0.5f);
    public static final Pos TARGET = new Pos("target", 0.62f, 0.58f);
    public static final Pos ARROWS = new Pos("arrows", 0.5f, 0.5f);
    private static final Pos[] ALL = {INVENTORY, TARGET, ARROWS};

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("glassdls-hud.properties");

    private HudLayout() {}

    public static int x(Pos p, int screenW, int elemW) {
        return Math.round(p.fx * Math.max(0, screenW - elemW));
    }

    public static int y(Pos p, int screenH, int elemH) {
        return Math.round(p.fy * Math.max(0, screenH - elemH));
    }

    /** Ставит элемент так, чтобы его левый верхний угол оказался в (x, y). */
    public static void setFromTopLeft(Pos p, int x, int y, int screenW, int screenH, int elemW, int elemH) {
        p.fx = clamp(x / (float) Math.max(1, screenW - elemW));
        p.fy = clamp(y / (float) Math.max(1, screenH - elemH));
    }

    public static float clamp(float v) { return Math.max(0.0f, Math.min(1.0f, v)); }

    public static void resetAll() {
        for (Pos p : ALL) p.reset();
        save();
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (Pos p : ALL) {
            try {
                String x = props.getProperty(p.id + ".x");
                String y = props.getProperty(p.id + ".y");
                if (x != null) p.fx = clamp(Float.parseFloat(x));
                if (y != null) p.fy = clamp(Float.parseFloat(y));
            } catch (NumberFormatException ignored) {}
        }
    }

    public static void save() {
        Properties props = new Properties();
        for (Pos p : ALL) {
            props.setProperty(p.id + ".x", String.valueOf(p.fx));
            props.setProperty(p.id + ".y", String.valueOf(p.fy));
        }
        try (OutputStream out = Files.newOutputStream(FILE)) {
            props.store(out, "glassDLS HUD positions");
        } catch (IOException ignored) {}
    }
}
