package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

import java.util.Comparator;

public class KillAura extends Module {
    private static final double RANGE = 4.0;
    public static boolean attackPlayers = false;

    public KillAura() {
        super("KillAura", "Бьёт ближайших мобов в радиусе 4 блоков", Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient client) {
        PlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        LivingEntity target = client.world
                .getEntitiesByClass(LivingEntity.class,
                        player.getBoundingBox().expand(RANGE),
                        e -> e != player && e.isAlive()
                                && (e instanceof HostileEntity || (attackPlayers && e instanceof PlayerEntity)))
                .stream()
                .min(Comparator.comparingDouble(player::squaredDistanceTo))
                .orElse(null);

        if (target == null || player.distanceTo(target) > RANGE) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }
}
