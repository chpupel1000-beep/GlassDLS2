package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class KillAura extends Module {
    /** Бить ли игроков (включается модулем AuraPlayers). */
    public static boolean attackPlayers = false;

    // Дальность удара: считается от глаз до ближайшей точки хитбокса цели,
    // так же, как проверяет сервер. Больше 4.0 сервер всё равно не примет.
    private static final String[] NAMES = {"Reach 3.0", "Reach 3.5", "Reach 4.0"};
    private static final double[] REACH = {3.0, 3.5, 4.0};

    public KillAura() {
        super("KillAura", "Бьёт ближайших мобов в пределах досягаемости", Category.COMBAT);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    private double reach() {
        return REACH[Math.max(0, Math.min(mode, REACH.length - 1))];
    }

    @Override
    public void onTick(MinecraftClient client) {
        PlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        // Небольшой запас: сервер сравнивает дальность строго «меньше»
        double reach = reach() - 0.05;
        Vec3d eye = player.getEyePos();

        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity e : client.world.getEntitiesByClass(
                LivingEntity.class, player.getBoundingBox().expand(reach + 1.0), x -> true)) {
            if (e == player || !e.isAlive() || !isValid(e)) continue;
            double d = distanceToBox(eye, e.getBoundingBox());
            if (d > reach || d >= best) continue;
            if (!player.canSee(e)) continue; // не бить сквозь стены
            target = e;
            best = d;
        }
        if (target == null) return;

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static boolean isValid(LivingEntity e) {
        return e instanceof HostileEntity || (attackPlayers && e instanceof PlayerEntity);
    }

    /** Расстояние от точки до ближайшей точки коробки. */
    private static double distanceToBox(Vec3d p, Box b) {
        double x = MathHelper.clamp(p.x, b.minX, b.maxX);
        double y = MathHelper.clamp(p.y, b.minY, b.maxY);
        double z = MathHelper.clamp(p.z, b.minZ, b.maxZ);
        return p.distanceTo(new Vec3d(x, y, z));
    }
}
