package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;

import java.util.List;

/**
 * Убирает лишние эффекты на экране:
 *  - NoFire: огонь перед глазами и языки пламени на существах (урон от огня остаётся);
 *  - NoParticles: все частицы.
 * Режим выбирается кнопкой на карточке.
 */
public class NoRender extends Module {
    private static final String[] NAMES = {"Fire + Particles", "Fire", "Particles"};

    public NoRender() {
        super("NoRender", "Убирает огонь на экране и частицы", Category.VISUALS);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    public boolean noFire() { return mode == 0 || mode == 1; }

    public boolean noParticles() { return mode == 0 || mode == 2; }

    @Override
    public void onTick(MinecraftClient client) {
        // Частицы, появившиеся за тик, стираются до отрисовки кадра
        if (noParticles() && client.particleManager != null) {
            client.particleManager.clearParticles();
        }
    }
}
