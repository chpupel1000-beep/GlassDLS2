package com.example.killaura.module;

import com.example.killaura.HudDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Шляпа-треугольник на голове игрока. Цвет, длина и ширина выбираются в меню.
 * Шляпу видно только тебе: она рисуется на экране в точке над головой игрока.
 * Шляпа рисуется только на тебе и видна в виде от третьего лица (F5).
 */
public class Hat extends Module {
    private static final String[] COLOR_NAMES =
            {"Ice", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink", "White", "Black"};
    private static final int[] COLORS =
            {0x7DD3FC, 0xEF4444, 0xF97316, 0xFACC15, 0x22C55E, 0x06B6D4, 0x3B82F6, 0xA855F7, 0xEC4899, 0xF8FAFC, 0x111827};
    private static final String[] LENGTH_NAMES = {"0.2", "0.3", "0.5", "0.7", "1.0", "1.5", "2.0"};
    private static final double[] LENGTHS = {0.2, 0.3, 0.5, 0.7, 1.0, 1.5, 2.0};
    private static final String[] WIDTH_NAMES = {"0.3", "0.5", "0.7", "1.0", "1.4", "1.8", "2.2"};
    private static final double[] WIDTHS = {0.3, 0.5, 0.7, 1.0, 1.4, 1.8, 2.2};

    private final Setting color = addSetting("Color", COLOR_NAMES, 0);
    private final Setting length = addSetting("Length", LENGTH_NAMES, 1);
    private final Setting width = addSetting("Width", WIDTH_NAMES, 4);

    private long lastTick = System.nanoTime();

    public Hat() {
        super("Hat", "Шляпа-треугольник на голове: цвет, длина, ширина", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        lastTick = System.nanoTime();
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int w = c.getScaledWindowWidth();
        int h = c.getScaledWindowHeight();

        // Камера: позиция и оси (вперёд, вправо, вверх)
        Camera cam = client.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();
        double yaw = Math.toRadians(cam.getYaw());
        double pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);
        double tanHalf = Math.tan(Math.toRadians(client.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / h;

        // Доля тика, чтобы шляпа двигалась плавно вместе с игроком
        double delta = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        boolean firstPerson = client.options.getPerspective().isFirstPerson();

        int rgb = COLORS[color.index];
        double radius = WIDTHS[width.index] / 2.0;
        double len = LENGTHS[length.index];
        final int seg = 10;
        Vec3d light = new Vec3d(0.4, 0.8, 0.45).normalize();

        for (PlayerEntity p : client.world.getPlayers()) {
            if (!p.isAlive()) continue;
            if (p != client.player || firstPerson) continue; // шляпа только на тебе, видна в 3-м лице

            double x = p.prevX + (p.getX() - p.prevX) * delta;
            double y = p.prevY + (p.getY() - p.prevY) * delta;
            double z = p.prevZ + (p.getZ() - p.prevZ) * delta;

            Vec3d base = new Vec3d(x, y + p.getHeight() - 0.12, z);
            Vec3d tip = base.add(0.0, len, 0.0);
            double[] pt = project(tip, camPos, fwd, right, up, tanHalf, aspect, w, h);
            if (pt == null) continue;

            // 3D-конус: боковые грани, повёрнутые к камере, закрашены по освещению
            for (int i = 0; i < seg; i++) {
                double a0 = 2 * Math.PI * i / seg, a1 = 2 * Math.PI * (i + 1) / seg;
                Vec3d c0 = base.add(Math.cos(a0) * radius, 0, Math.sin(a0) * radius);
                Vec3d c1 = base.add(Math.cos(a1) * radius, 0, Math.sin(a1) * radius);
                Vec3d n = c0.subtract(tip).crossProduct(c1.subtract(tip));
                Vec3d out = c0.add(c1).multiply(0.5).subtract(base);
                if (n.dotProduct(out) < 0) n = n.multiply(-1);
                if (n.lengthSquared() < 1e-9) continue;
                if (n.dotProduct(camPos.subtract(tip)) <= 0) continue; // задняя грань
                double k = 0.5 + 0.5 * Math.max(0.0, n.normalize().dotProduct(light));
                double[] q0 = project(c0, camPos, fwd, right, up, tanHalf, aspect, w, h);
                double[] q1 = project(c1, camPos, fwd, right, up, tanHalf, aspect, w, h);
                if (q0 == null || q1 == null) continue;
                HudDraw.fillTriangle(c, pt[0], pt[1], q0[0], q0[1], q1[0], q1[1], 0xFF000000 | shade(rgb, k));
            }
        }
    }

    /** Точка мира -> координаты на экране. null, если точка позади камеры. */
    private static double[] project(Vec3d p, Vec3d camPos, Vec3d fwd, Vec3d right, Vec3d up,
                                    double tanHalf, double aspect, int w, int h) {
        Vec3d d = p.subtract(camPos);
        double z = d.dotProduct(fwd);
        if (z < 0.1) return null;
        double nx = d.dotProduct(right) / (z * tanHalf * aspect);
        double ny = d.dotProduct(up) / (z * tanHalf);
        return new double[]{w * 0.5 * (1.0 + nx), h * 0.5 * (1.0 - ny)};
    }

    private static int shade(int rgb, double k) {
        int r = (int) (((rgb >> 16) & 0xFF) * k);
        int g = (int) (((rgb >> 8) & 0xFF) * k);
        int b = (int) ((rgb & 0xFF) * k);
        return (r << 16) | (g << 8) | b;
    }
}
