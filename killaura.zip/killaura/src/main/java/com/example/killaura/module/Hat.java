package com.example.killaura.module;

import com.example.killaura.HudDraw;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Шляпа-треугольник на голове игрока. Цвет, длина и ширина выбираются в меню.
 * Шляпу видно только тебе: она рисуется на экране в точке над головой игрока.
 * Шляпа рисуется только на тебе и видна в виде от третьего лица (F5).
 */
public class Hat extends Module {
    private static final String[] COLOR_NAMES =
            {"Ice", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink", "White", "Black"};
    private static final int[] COLORS =
            {0x7DD3FC, 0xEF4444, 0xF97316, 0xFACC15, 0x22C55E, 0x06B6D4, 0x3B82F6, 0xA855F7, 0xEC4899, 0xF8FAFC, 0x111827};
    private static final String[] LENGTH_NAMES = {"0.3", "0.5", "0.7", "1.0", "1.5", "2.0"};
    private static final double[] LENGTHS = {0.3, 0.5, 0.7, 1.0, 1.5, 2.0};
    private static final String[] WIDTH_NAMES = {"0.3", "0.5", "0.7", "1.0", "1.4"};
    private static final double[] WIDTHS = {0.3, 0.5, 0.7, 1.0, 1.4};

    private final Setting color = addSetting("Color", COLOR_NAMES, 0);
    private final Setting length = addSetting("Length", LENGTH_NAMES, 2);
    private final Setting width = addSetting("Width", WIDTH_NAMES, 2);

    private long lastTick = System.nanoTime();

    public Hat() {
        super("Hat", "Шляпа-треугольник на голове: цвет, длина, ширина", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient client) {
        lastTick = System.nanoTime();
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int w = c.getScaledWindowWidth();
        int h = c.getScaledWindowHeight();

        // Камера: позиция и оси (вперёд, вправо, вверх)
        Camera cam = client.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();
        double yaw = Math.toRadians(cam.getYaw());
        double pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);
        double tanHalf = Math.tan(Math.toRadians(client.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / h;

        // Доля тика, чтобы шляпа двигалась плавно вместе с игроком
        double delta = Math.min(1.0, (System.nanoTime() - lastTick) / 50_000_000.0);
        boolean firstPerson = client.options.getPerspective().isFirstPerson();

        int rgb = COLORS[color.index];
        int light = 0xFF000000 | rgb;
        int dark = 0xFF000000 | shade(rgb, 0.75);
        double halfWidth = WIDTHS[width.index] / 2.0;
        double len = LENGTHS[length.index];

        for (PlayerEntity p : client.world.getPlayers()) {
            if (!p.isAlive()) continue;
            boolean self = p == client.player;
            if (self && firstPerson) continue;
            if (!self) continue; // шляпа только на тебе

            double x = p.prevX + (p.getX() - p.prevX) * delta;
            double y = p.prevY + (p.getY() - p.prevY) * delta;
            double z = p.prevZ + (p.getZ() - p.prevZ) * delta;

            Vec3d base = new Vec3d(x, y + p.getHeight() - 0.05, z);
            Vec3d left = base.subtract(right.multiply(halfWidth));
            Vec3d rightPt = base.add(right.multiply(halfWidth));
            Vec3d tip = base.add(0.0, len, 0.0);

            double[] a = project(tip, camPos, fwd, right, up, tanHalf, aspect, w, h);
            double[] b = project(left, camPos, fwd, right, up, tanHalf, aspect, w, h);
            double[] m = project(base, camPos, fwd, right, up, tanHalf, aspect, w, h);
            double[] d = project(rightPt, camPos, fwd, right, up, tanHalf, aspect, w, h);
            if (a == null || b == null || m == null || d == null) continue;

            // Две половины разного оттенка дают объём
            HudDraw.fillTriangle(c, a[0], a[1], b[0], b[1], m[0], m[1], light);
            HudDraw.fillTriangle(c, a[0], a[1], m[0], m[1], d[0], d[1], dark);
        }
    }

    /** Точка мира -> координаты на экране. null, если точка позади камеры. */
    private static double[] project(Vec3d p, Vec3d camPos, Vec3d fwd, Vec3d right, Vec3d up,
                                    double tanHalf, double aspect, int w, int h) {
        Vec3d d = p.subtract(camPos);
        double z = d.dotProduct(fwd);
        if (z < 0.1) return null;
        double nx = d.dotProduct(right) / (z * tanHalf * aspect);
        double ny = d.dotProduct(up) / (z * tanHalf);
        return new double[]{w * 0.5 * (1.0 + nx), h * 0.5 * (1.0 - ny)};
    }

    private static int shade(int rgb, double k) {
        int r = (int) (((rgb >> 16) & 0xFF) * k);
        int g = (int) (((rgb >> 8) & 0xFF) * k);
        int b = (int) ((rgb & 0xFF) * k);
        return (r << 16) | (g << 8) | b;
    }
}
