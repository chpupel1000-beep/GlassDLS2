package com.example.killaura;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;

/** Проекция точек мира на экран, чтобы рисовать фигуры вокруг игроков в HUD. */
public final class WorldDraw {
    public final Vec3d camPos;
    private final Vec3d fwd, right, up;
    private final double tanHalf, aspect;
    private final int w, h;

    public WorldDraw(MinecraftClient client, DrawContext c) {
        w = c.getScaledWindowWidth();
        h = c.getScaledWindowHeight();
        Camera cam = client.gameRenderer.getCamera();
        camPos = cam.getPos();
        double yaw = Math.toRadians(cam.getYaw());
        double pitch = Math.toRadians(cam.getPitch());
        fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        right = new Vec3d(-Math.cos(yaw), 0.0, -Math.sin(yaw));
        up = right.crossProduct(fwd);
        tanHalf = Math.tan(Math.toRadians(client.options.getFov().getValue()) / 2.0);
        aspect = (double) w / h;
    }

    /** Координаты на экране или null, если точка позади камеры. */
    public double[] project(Vec3d p) {
        Vec3d d = p.subtract(camPos);
        double z = d.dotProduct(fwd);
        if (z < 0.1) return null;
        double nx = d.dotProduct(right) / (z * tanHalf * aspect);
        double ny = d.dotProduct(up) / (z * tanHalf);
        return new double[]{w * 0.5 * (1.0 + nx), h * 0.5 * (1.0 - ny)};
    }

    public void tri(DrawContext c, Vec3d a, Vec3d b, Vec3d d, int color) {
        double[] pa = project(a), pb = project(b), pd = project(d);
        if (pa == null || pb == null || pd == null) return;
        HudDraw.fillTriangle(c, pa[0], pa[1], pb[0], pb[1], pd[0], pd[1], color);
    }
}
