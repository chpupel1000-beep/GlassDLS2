package com.example.killaura.mixin;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.Hitbox;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    // Расширяет или сужает зону, по которой прицел определяет попадание
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true, require = 0)
    private void glassdls$targetingMargin(CallbackInfoReturnable<Float> cir) {
        Hitbox hitbox = KillAuraMod.MODULES.get(Hitbox.class);
        if (hitbox == null || !hitbox.isEnabled()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        Entity self = (Entity) (Object) this;
        // Только клиентский мир и только чужие существа
        if (client.world == null || self.getWorld() != client.world || self == client.player) return;

        cir.setReturnValue(cir.getReturnValue() + hitbox.margin());
    }
}
