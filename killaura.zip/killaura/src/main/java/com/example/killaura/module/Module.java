package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    /** Настройка модуля: набор вариантов, выбранный вариант листается кнопкой на карточке. */
    public static final class Setting {
        public final String name;
        public final String[] options;
        public int index;

        public Setting(String name, String[] options, int defaultIndex) {
            this.name = name;
            this.options = options;
            this.index = Math.max(0, Math.min(defaultIndex, options.length - 1));
        }

        public String value() { return options[index]; }

        /** Листает вперёд (delta = 1) или назад (delta = -1). */
        public void cycle(int delta) {
            int n = options.length;
            index = ((index + delta) % n + n) % n;
        }
    }

    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    /** Клавиша включения (код GLFW), -1 = не назначена. Меняется командой .bind */
    public int key = GLFW.GLFW_KEY_UNKNOWN;
    public boolean keyDown;

    /** Номер выбранного режима (если у модуля есть режимы). */
    public int mode;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }

    protected Setting addSetting(String settingName, String[] options, int defaultIndex) {
        Setting s = new Setting(settingName, options, defaultIndex);
        settings.add(s);
        return s;
    }

    public List<Setting> getSettings() { return settings; }

    /** Список режимов. Пустой = у модуля нет режимов. */
    public List<String> getModes() { return List.of(); }

    public String getModeName() {
        List<String> modes = getModes();
        if (modes.isEmpty()) return "";
        return modes.get(Math.max(0, Math.min(mode, modes.size() - 1)));
    }

    public void cycleMode() {
        List<String> modes = getModes();
        if (!modes.isEmpty()) mode = (mode + 1) % modes.size();
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}

    /** Рисование поверх игрового экрана (HUD). Вызывается, пока модуль включён. */
    public void renderHud(DrawContext context) {}
}
