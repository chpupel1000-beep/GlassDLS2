package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;

    /** Клавиша включения (код GLFW), -1 = не назначена. Меняется командой .bind */
    public int key = GLFW.GLFW_KEY_UNKNOWN;
    public boolean keyDown;

    /** Номер выбранного режима (если у модуля есть режимы). */
    public int mode;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }

    /** Список режимов. Пустой = у модуля нет режимов. */
    public List<String> getModes() { return List.of(); }

    public String getModeName() {
        List<String> modes = getModes();
        if (modes.isEmpty()) return "";
        return modes.get(Math.max(0, Math.min(mode, modes.size() - 1)));
    }

    public void cycleMode() {
        List<String> modes = getModes();
        if (!modes.isEmpty()) mode = (mode + 1) % modes.size();
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}

    /** Рисование поверх игрового экрана (HUD). Вызывается, пока модуль включён. */
    public void renderHud(DrawContext context) {}
}
