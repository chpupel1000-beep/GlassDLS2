package com.example.killaura.gui;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.Category;
import com.example.killaura.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.stream.Collectors;

/** Меню в стиле матового стекла. */
public class ClickGuiScreen extends Screen {
    // Цвета (ARGB)
    private static final int PANEL = 0x66101826;
    private static final int SHEEN = 0x2EFFFFFF;
    private static final int BORDER = 0x66FFFFFF;
    private static final int SIDEBAR = 0x1AFFFFFF;
    private static final int SIDEBAR_BORDER = 0x33FFFFFF;
    private static final int CARD = 0x22FFFFFF;
    private static final int CARD_HOVER = 0x38FFFFFF;
    private static final int CARD_BORDER = 0x30FFFFFF;
    private static final int ACCENT = 0xFF7DD3FC;
    private static final int ACCENT_SOFT = 0x447DD3FC;
    private static final int ACCENT_CARD = 0x2E7DD3FC;
    private static final int TEXT = 0xFFF1F5F9;
    private static final int DIM = 0xFFA9B4C6;
    private static final int SWITCH_OFF = 0x55FFFFFF;

    private static final int CARD_H = 34;
    private static final int GAP = 6;
    private static final int CAT_H = 16;
    private static final int CAT_STEP = 19;

    private static Category selected = Category.COMBAT;
    private double scroll = 0;

    // Раскладка, пересчитывается в layout()
    private int px, py, pw, ph, sbw, cx, cy, cw, ch;

    public ClickGuiScreen() {
        super(Text.literal("glassDLS"));
    }

    private void layout() {
        pw = Math.min(width - 16, 420);
        ph = Math.min(height - 16, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sbw = Math.min(84, pw / 3);
        cx = px + sbw + 8;
        cy = py + 28;
        cw = pw - sbw - 16;
        ch = ph - 36;
    }

    private int columns() { return cw >= 190 ? 2 : 1; }
    private int cardW() { int c = columns(); return (cw - GAP * (c - 1)) / c; }

    private List<Module> visibleModules() {
        return KillAuraMod.MODULES.getModules().stream()
                .filter(m -> m.getCategory() == selected)
                .collect(Collectors.toList());
    }

    private int contentHeight(int count) {
        int rows = (count + columns() - 1) / columns();
        return rows == 0 ? 0 : rows * (CARD_H + GAP) - GAP;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // Прямоугольник со слегка скруглёнными углами (полосы не накладываются)
    private static void rect(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + 1, color);
        c.fill(x, y + 1, x + w, y + h - 1, color);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
    }

    // Тонкая рамка вокруг прямоугольника
    private static void border(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + 1, color);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
        c.fill(x, y + 1, x + 1, y + h - 1, color);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    // Стеклянная панель: тонировка, блик сверху, светлая рамка
    private static void glass(DrawContext c, int x, int y, int w, int h, int tint, int borderColor) {
        rect(c, x, y, w, h, tint);
        c.fillGradient(x + 1, y + 1, x + w - 1, y + Math.max(2, h / 2), 0x22FFFFFF, 0x00FFFFFF);
        border(c, x, y, w, h, borderColor);
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta); // размытый фон мира
        layout();

        // Главная стеклянная панель
        rect(c, px, py, pw, ph, PANEL);
        c.fillGradient(px + 1, py + 1, px + pw - 1, py + ph / 3, SHEEN, 0x00FFFFFF);
        border(c, px, py, pw, ph, BORDER);

        // Боковая панель
        rect(c, px + 4, py + 4, sbw - 4, ph - 8, SIDEBAR);
        border(c, px + 4, py + 4, sbw - 4, ph - 8, SIDEBAR_BORDER);
        c.drawTextWithShadow(textRenderer, "glassDLS", px + 11, py + 10, ACCENT);

        int y = py + 28;
        for (Category cat : Category.values()) {
            boolean sel = cat == selected;
            boolean hov = inside(mx, my, px + 8, y, sbw - 12, CAT_H);
            if (sel) {
                rect(c, px + 8, y, sbw - 12, CAT_H, ACCENT_SOFT);
                border(c, px + 8, y, sbw - 12, CAT_H, ACCENT);
            } else if (hov) {
                rect(c, px + 8, y, sbw - 12, CAT_H, 0x22FFFFFF);
            }
            c.drawTextWithShadow(textRenderer, cat.title, px + 13, y + 4, sel ? TEXT : DIM);
            y += CAT_STEP;
        }

        // Заголовок
        c.drawTextWithShadow(textRenderer, selected.title, cx, py + 10, TEXT);
        String hint = "Esc — закрыть";
        c.drawTextWithShadow(textRenderer, hint,
                px + pw - textRenderer.getWidth(hint) - 8, py + 10, DIM);

        // Карточки модулей
        List<Module> list = visibleModules();
        double maxScroll = Math.max(0, contentHeight(list.size()) - ch);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        c.enableScissor(cx, cy, cx + cw, cy + ch);
        if (list.isEmpty()) {
            c.drawTextWithShadow(textRenderer, "Скоро появятся новые функции", cx, cy + 4, DIM);
        }
        int cols = columns();
        int w = cardW();
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int x = cx + (i % cols) * (w + GAP);
            int yy = cy + (i / cols) * (CARD_H + GAP) - (int) scroll;
            boolean hov = inside(mx, my, x, yy, w, CARD_H) && my >= cy && my < cy + ch;
            boolean on = m.isEnabled();

            rect(c, x, yy, w, CARD_H, on ? ACCENT_CARD : (hov ? CARD_HOVER : CARD));
            c.fillGradient(x + 1, yy + 1, x + w - 1, yy + CARD_H / 2, 0x1CFFFFFF, 0x00FFFFFF);
            border(c, x, yy, w, CARD_H, on ? ACCENT : CARD_BORDER);

            c.drawTextWithShadow(textRenderer, m.getName(), x + 8, yy + 7, TEXT);
            if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                String bind = "[" + InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() + "]";
                c.drawTextWithShadow(textRenderer, bind,
                        x + 8 + textRenderer.getWidth(m.getName()) + 4, yy + 7, ACCENT);
            }
            if (m.getModes().isEmpty()) {
                String desc = textRenderer.trimToWidth(m.getDescription(), w - 46);
                c.drawTextWithShadow(textRenderer, desc, x + 8, yy + 20, DIM);
            } else {
                String chip = "< " + m.getModeName() + " >";
                int chipW = textRenderer.getWidth(chip) + 8;
                boolean chipHov = inside(mx, my, x + 8, yy + 18, chipW, 12) && my >= cy && my < cy + ch;
                rect(c, x + 8, yy + 18, chipW, 12, chipHov ? 0x44FFFFFF : 0x28FFFFFF);
                border(c, x + 8, yy + 18, chipW, 12, ACCENT);
                c.drawTextWithShadow(textRenderer, chip, x + 12, yy + 20, TEXT);
            }

            // Переключатель
            int sx = x + w - 28, sy = yy + (CARD_H - 12) / 2;
            rect(c, sx, sy, 22, 12, on ? ACCENT : SWITCH_OFF);
            border(c, sx, sy, 22, 12, on ? 0x88FFFFFF : 0x44FFFFFF);
            int kx = on ? sx + 12 : sx + 2;
            rect(c, kx, sy + 2, 8, 8, 0xFFFFFFFF);
        }
        c.disableScissor();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();
        if (button == 0) {
            // Категории
            int y = py + 28;
            for (Category cat : Category.values()) {
                if (inside(mx, my, px + 8, y, sbw - 12, CAT_H)) {
                    selected = cat;
                    scroll = 0;
                    return true;
                }
                y += CAT_STEP;
            }
            // Модули
            if (inside(mx, my, cx, cy, cw, ch)) {
                List<Module> list = visibleModules();
                int cols = columns();
                int w = cardW();
                for (int i = 0; i < list.size(); i++) {
                    int x = cx + (i % cols) * (w + GAP);
                    int yy = cy + (i / cols) * (CARD_H + GAP) - (int) scroll;
                    if (inside(mx, my, x, yy, w, CARD_H)) {
                        Module m = list.get(i);
                        if (!m.getModes().isEmpty()) {
                            String chip = "< " + m.getModeName() + " >";
                            int chipW = textRenderer.getWidth(chip) + 8;
                            if (inside(mx, my, x + 8, yy + 18, chipW, 12)) {
                                m.cycleMode();
                                KillAuraMod.MODULES.save();
                                return true;
                            }
                        }
                        m.toggle();
                        return true;
                    }
                }
            }
        }
        if (button == 1 && inside(mx, my, cx, cy, cw, ch)) {
            List<Module> list = visibleModules();
            int cols = columns();
            int w = cardW();
            for (int i = 0; i < list.size(); i++) {
                int x = cx + (i % cols) * (w + GAP);
                int yy = cy + (i / cols) * (CARD_H + GAP) - (int) scroll;
                if (inside(mx, my, x, yy, w, CARD_H) && !list.get(i).getModes().isEmpty()) {
                    list.get(i).cycleMode();
                    KillAuraMod.MODULES.save();
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll -= vertical * 14;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
