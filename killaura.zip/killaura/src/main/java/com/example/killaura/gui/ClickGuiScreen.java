package com.example.killaura.gui;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.Category;
import com.example.killaura.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.stream.Collectors;

/** Меню в стиле матового стекла. */
public class ClickGuiScreen extends Screen {
    // Цвета (ARGB)
    private static final int PANEL = 0x66101826;
    private static final int SHEEN = 0x2EFFFFFF;
    private static final int BORDER = 0x66FFFFFF;
    private static final int SIDEBAR = 0x1AFFFFFF;
    private static final int SIDEBAR_BORDER = 0x33FFFFFF;
    private static final int CARD = 0x22FFFFFF;
    private static final int CARD_HOVER = 0x38FFFFFF;
    private static final int CARD_BORDER = 0x30FFFFFF;
    private static final int ACCENT = 0xFF7DD3FC;
    private static final int ACCENT_SOFT = 0x447DD3FC;
    private static final int ACCENT_CARD = 0x2E7DD3FC;
    private static final int TEXT = 0xFFF1F5F9;
    private static final int DIM = 0xFFA9B4C6;
    private static final int SWITCH_OFF = 0x55FFFFFF;

    private static final int CARD_H = 34;
    private static final int GAP = 6;
    private static final int CAT_H = 16;
    private static final int CAT_STEP = 19;
    private static final int CHIP_H = 12;
    private static final int CHIP_STEP = 14;
    private static final int CHIP_Y = 18;

    private static Category selected = Category.COMBAT;
    private double scroll = 0;

    // Раскладка, пересчитывается в layout()
    private int px, py, pw, ph, sbw, cx, cy, cw, ch;

    public ClickGuiScreen() {
        super(Text.literal("glassDLS"));
    }

    private void layout() {
        pw = Math.min(width - 16, 420);
        ph = Math.min(height - 16, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sbw = Math.min(84, pw / 3);
        cx = px + sbw + 8;
        cy = py + 28;
        cw = pw - sbw - 16;
        ch = ph - 36;
    }

    private int columns() { return cw >= 190 ? 2 : 1; }
    private int cardW() { int c = columns(); return (cw - GAP * (c - 1)) / c; }

    private List<Module> visibleModules() {
        return KillAuraMod.MODULES.getModules().stream()
                .filter(m -> m.getCategory() == selected)
                .collect(Collectors.toList());
    }

    /** Высота карточки: у модулей с настройками под названием стоит по кнопке на каждую. */
    private static int cardHeight(Module m) {
        int n = m.getSettings().size();
        return n > 0 ? CHIP_Y + n * CHIP_STEP + 2 : CARD_H;
    }

    /** Раскладка карточек: [0] = x, [1] = y, [2] = высота каждой карточки, [3][0] = высота всего списка. */
    private int[][] cardLayout(List<Module> list) {
        int cols = columns();
        int w = cardW();
        int n = list.size();
        int[] xs = new int[n], ys = new int[n], hs = new int[n];
        int y = 0;
        for (int row = 0; row * cols < n; row++) {
            int rowH = 0;
            for (int k = 0; k < cols && row * cols + k < n; k++) {
                rowH = Math.max(rowH, cardHeight(list.get(row * cols + k)));
            }
            for (int k = 0; k < cols && row * cols + k < n; k++) {
                int i = row * cols + k;
                xs[i] = k * (w + GAP);
                ys[i] = y;
                hs[i] = rowH;
            }
            y += rowH + GAP;
        }
        return new int[][]{xs, ys, hs, {Math.max(0, y - GAP)}};
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // Прямоугольник со слегка скруглёнными углами (полосы не накладываются)
    private static void rect(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + 1, color);
        c.fill(x, y + 1, x + w, y + h - 1, color);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
    }

    // Тонкая рамка вокруг прямоугольника
    private static void border(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + 1, color);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
        c.fill(x, y + 1, x + 1, y + h - 1, color);
        c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    private int chipWidth(String text) { return textRenderer.getWidth(text) + 8; }

    private void drawChip(DrawContext c, int x, int y, String text, int mx, int my) {
        int w = chipWidth(text);
        boolean hov = inside(mx, my, x, y, w, CHIP_H) && my >= cy && my < cy + ch;
        rect(c, x, y, w, CHIP_H, hov ? 0x44FFFFFF : 0x28FFFFFF);
        border(c, x, y, w, CHIP_H, ACCENT);
        c.drawTextWithShadow(textRenderer, text, x + 4, y + 2, TEXT);
    }

    private static String settingText(Module.Setting s) { return s.name + ": " + s.value(); }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta); // размытый фон мира
        layout();

        // Главная стеклянная панель
        rect(c, px, py, pw, ph, PANEL);
        c.fillGradient(px + 1, py + 1, px + pw - 1, py + ph / 3, SHEEN, 0x00FFFFFF);
        border(c, px, py, pw, ph, BORDER);

        // Боковая панель
        rect(c, px + 4, py + 4, sbw - 4, ph - 8, SIDEBAR);
        border(c, px + 4, py + 4, sbw - 4, ph - 8, SIDEBAR_BORDER);
        c.drawTextWithShadow(textRenderer, "glassDLS", px + 11, py + 10, ACCENT);

        int y = py + 28;
        for (Category cat : Category.values()) {
            boolean sel = cat == selected;
            boolean hov = inside(mx, my, px + 8, y, sbw - 12, CAT_H);
            if (sel) {
                rect(c, px + 8, y, sbw - 12, CAT_H, ACCENT_SOFT);
                border(c, px + 8, y, sbw - 12, CAT_H, ACCENT);
            } else if (hov) {
                rect(c, px + 8, y, sbw - 12, CAT_H, 0x22FFFFFF);
            }
            c.drawTextWithShadow(textRenderer, cat.title, px + 13, y + 4, sel ? TEXT : DIM);
            y += CAT_STEP;
        }

        // Кнопка редактора позиций HUD
        int ey = py + ph - 22;
        boolean eh = inside(mx, my, px + 8, ey, sbw - 12, 16);
        rect(c, px + 8, ey, sbw - 12, 16, eh ? 0x44FFFFFF : 0x22FFFFFF);
        border(c, px + 8, ey, sbw - 12, 16, ACCENT);
        c.drawTextWithShadow(textRenderer, "Позиции HUD", px + 13, ey + 4, TEXT);

        // Заголовок
        c.drawTextWithShadow(textRenderer, selected.title, cx, py + 10, TEXT);
        String hint = "Esc — закрыть";
        c.drawTextWithShadow(textRenderer, hint,
                px + pw - textRenderer.getWidth(hint) - 8, py + 10, DIM);

        // Карточки модулей
        List<Module> list = visibleModules();
        int[][] lay = cardLayout(list);
        double maxScroll = Math.max(0, lay[3][0] - ch);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        c.enableScissor(cx, cy, cx + cw, cy + ch);
        if (list.isEmpty()) {
            c.drawTextWithShadow(textRenderer, "Скоро появятся новые функции", cx, cy + 4, DIM);
        }
        int w = cardW();
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int x = cx + lay[0][i];
            int yy = cy + lay[1][i] - (int) scroll;
            int hh = lay[2][i];
            boolean hov = inside(mx, my, x, yy, w, hh) && my >= cy && my < cy + ch;
            boolean on = m.isEnabled();

            rect(c, x, yy, w, hh, on ? ACCENT_CARD : (hov ? CARD_HOVER : CARD));
            c.fillGradient(x + 1, yy + 1, x + w - 1, yy + CARD_H / 2, 0x1CFFFFFF, 0x00FFFFFF);
            border(c, x, yy, w, hh, on ? ACCENT : CARD_BORDER);

            c.drawTextWithShadow(textRenderer, m.getName(), x + 8, yy + 7, TEXT);
            if (m.key != GLFW.GLFW_KEY_UNKNOWN) {
                String bind = "[" + InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString() + "]";
                c.drawTextWithShadow(textRenderer, bind,
                        x + 8 + textRenderer.getWidth(m.getName()) + 4, yy + 7, ACCENT);
            }

            List<Module.Setting> settings = m.getSettings();
            if (!settings.isEmpty()) {
                for (int k = 0; k < settings.size(); k++) {
                    drawChip(c, x + 8, yy + CHIP_Y + k * CHIP_STEP, settingText(settings.get(k)), mx, my);
                }
            } else if (!m.getModes().isEmpty()) {
                drawChip(c, x + 8, yy + CHIP_Y, "< " + m.getModeName() + " >", mx, my);
            } else {
                String desc = textRenderer.trimToWidth(m.getDescription(), w - 46);
                c.drawTextWithShadow(textRenderer, desc, x + 8, yy + 20, DIM);
            }

            // Переключатель
            int sx = x + w - 28, sy = yy + (CARD_H - 12) / 2;
            rect(c, sx, sy, 22, 12, on ? ACCENT : SWITCH_OFF);
            border(c, sx, sy, 22, 12, on ? 0x88FFFFFF : 0x44FFFFFF);
            int kx = on ? sx + 12 : sx + 2;
            rect(c, kx, sy + 2, 8, 8, 0xFFFFFFFF);
        }
        c.disableScissor();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        layout();

        if (button == 0 || button == 1) {
            boolean forward = button == 0;

            // Модули (левая кнопка листает вперёд, правая назад; клик по остальной карточке включает модуль)
            if (inside(mx, my, cx, cy, cw, ch)) {
                List<Module> list = visibleModules();
                int[][] lay = cardLayout(list);
                int w = cardW();
                for (int i = 0; i < list.size(); i++) {
                    int x = cx + lay[0][i];
                    int yy = cy + lay[1][i] - (int) scroll;
                    int hh = lay[2][i];
                    if (!inside(mx, my, x, yy, w, hh)) continue;

                    Module m = list.get(i);
                    List<Module.Setting> settings = m.getSettings();
                    for (int k = 0; k < settings.size(); k++) {
                        Module.Setting s = settings.get(k);
                        if (inside(mx, my, x + 8, yy + CHIP_Y + k * CHIP_STEP, chipWidth(settingText(s)), CHIP_H)) {
                            s.cycle(forward ? 1 : -1);
                            KillAuraMod.MODULES.save();
                            return true;
                        }
                    }
                    if (settings.isEmpty() && !m.getModes().isEmpty()) {
                        String chip = "< " + m.getModeName() + " >";
                        if (inside(mx, my, x + 8, yy + CHIP_Y, chipWidth(chip), CHIP_H) || !forward) {
                            m.cycleMode();
                            KillAuraMod.MODULES.save();
                            return true;
                        }
                    }
                    if (forward) {
                        m.toggle();
                        return true;
                    }
                    return true;
                }
            }
        }

        if (button == 0) {
            if (inside(mx, my, px + 8, py + ph - 22, sbw - 12, 16)) {
                client.setScreen(new HudEditorScreen(this));
                return true;
            }
            // Категории
            int y = py + 28;
            for (Category cat : Category.values()) {
                if (inside(mx, my, px + 8, y, sbw - 12, CAT_H)) {
                    selected = cat;
                    scroll = 0;
                    return true;
                }
                y += CAT_STEP;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll -= vertical * 14;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }
}
