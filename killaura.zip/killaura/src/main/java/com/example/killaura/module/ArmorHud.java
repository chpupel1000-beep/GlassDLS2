package com.example.killaura.module;

import com.example.killaura.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/** Броня и предметы в руках с полосками прочности. */
public class ArmorHud extends Module {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};

    public ArmorHud() {
        super("ArmorHud", "Броня и предметы в руках с прочностью", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int x = HudLayout.x(HudLayout.ARMOR, c.getScaledWindowWidth(), HudLayout.ARMOR.w);
        int y = HudLayout.y(HudLayout.ARMOR, c.getScaledWindowHeight(), HudLayout.ARMOR.h);
        c.fill(x, y, x + HudLayout.ARMOR.w, y + HudLayout.ARMOR.h, 0x44101826);
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack stack = client.player.getEquippedStack(SLOTS[i]);
            if (stack.isEmpty()) continue;
            int sx = x + 2 + i * 18, sy = y + 2;
            c.drawItem(stack, sx, sy);
            c.drawStackOverlay(client.textRenderer, stack, sx, sy);
        }
    }
}
