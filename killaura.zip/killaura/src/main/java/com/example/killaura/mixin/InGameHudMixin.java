package com.example.killaura.mixin;

import com.example.killaura.KillAuraMod;
import com.example.killaura.module.Crosshair;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    // Crosshair: прячем обычный прицел, когда включён свой
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void glassdls$hideCrosshair(CallbackInfo ci) {
        Crosshair c = KillAuraMod.MODULES.get(Crosshair.class);
        if (c != null && c.isEnabled()) ci.cancel();
    }
}
