package com.example.killaura.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;

import java.util.List;

/**
 * Эффект вокруг цели из частиц:
 *  Spirits: три светящихся духа летают по кругу,
 *  Square: квадрат вращается и ходит вверх-вниз,
 *  Ring: кольцо скользит по телу цели.
 * Цель: та, что бьёт KillAura, иначе существо под прицелом, иначе ближайший игрок.
 */
public class TargetHud extends Module {
    private static final String[] NAMES = {"Spirits", "Square", "Ring"};
    private static final double RANGE = 12.0;

    public TargetHud() {
        super("TargetHUD", "Эффект вокруг цели: духи, квадрат или кольцо", Category.VISUALS);
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    @Override
    public void onTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (client.player == null || world == null) return;

        LivingEntity e = findTarget(client);
        if (e == null) return;

        double t = world.getTime();
        double cx = e.getX(), cz = e.getZ(), base = e.getY();
        double r = e.getWidth() * 0.5 + 0.55;
        double h = e.getHeight();

        switch (Math.max(0, Math.min(mode, NAMES.length - 1))) {
            case 0 -> { // Spirits
                for (int i = 0; i < 3; i++) {
                    double a = t * 0.3 + i * (Math.PI * 2.0 / 3.0);
                    double y = base + h * (0.5 + 0.4 * Math.sin(t * 0.17 + i * 2.1));
                    spawn(world, cx + Math.cos(a) * r, y, cz + Math.sin(a) * r);
                }
            }
            case 1 -> { // Square
                double rot = t * 0.12;
                double y = base + h * (0.5 + 0.45 * Math.sin(t * 0.1));
                for (int side = 0; side < 4; side++) {
                    double[] c1 = corner(side, r);
                    double[] c2 = corner(side + 1, r);
                    for (int k = 0; k < 2; k++) {
                        double f = k / 2.0;
                        double px = c1[0] + (c2[0] - c1[0]) * f;
                        double pz = c1[1] + (c2[1] - c1[1]) * f;
                        double rx = px * Math.cos(rot) - pz * Math.sin(rot);
                        double rz = px * Math.sin(rot) + pz * Math.cos(rot);
                        spawn(world, cx + rx, y, cz + rz);
                    }
                }
            }
            default -> { // Ring
                double y = base + h * (0.5 + 0.5 * Math.sin(t * 0.12));
                for (int i = 0; i < 10; i++) {
                    double a = i * (Math.PI * 2.0 / 10.0);
                    spawn(world, cx + Math.cos(a) * r, y, cz + Math.sin(a) * r);
                }
            }
        }
    }

    private static void spawn(ClientWorld world, double x, double y, double z) {
        world.addParticle(ParticleTypes.SOUL_FIRE_FLAME, x, y, z, 0.0, 0.0, 0.0);
    }

    private static double[] corner(int i, double half) {
        return switch (i % 4) {
            case 0 -> new double[]{-half, -half};
            case 1 -> new double[]{half, -half};
            case 2 -> new double[]{half, half};
            default -> new double[]{-half, half};
        };
    }

    private static LivingEntity findTarget(MinecraftClient client) {
        LivingEntity aura = KillAura.currentTarget;
        if (aura != null && aura.isAlive() && aura.squaredDistanceTo(client.player) < 24.0 * 24.0) {
            return aura;
        }
        if (client.targetedEntity instanceof LivingEntity le && le != client.player && le.isAlive()) {
            return le;
        }
        AbstractClientPlayerEntity best = null;
        double bestDist = RANGE * RANGE;
        for (AbstractClientPlayerEntity p : client.world.getPlayers()) {
            if (p == client.player || !p.isAlive()) continue;
            double d = p.squaredDistanceTo(client.player);
            if (d < bestDist) {
                best = p;
                bestDist = d;
            }
        }
        return best;
    }
}
