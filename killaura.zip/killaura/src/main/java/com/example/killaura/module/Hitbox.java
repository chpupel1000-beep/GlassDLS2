package com.example.killaura.module;

import java.util.List;

/**
 * Меняет размер зоны попадания других существ (только для прицела на клиенте).
 * Модель и внешний вид существа не меняются. Размер выбирается кнопкой на карточке.
 */
public class Hitbox extends Module {
    private static final String[] NAMES = {"Size -0.2", "Size -0.1", "Size +0.1", "Size +0.2",
            "Size +0.3", "Size +0.5", "Size +0.8", "Size +1.0"};
    private static final float[] VALUES = {-0.2f, -0.1f, 0.1f, 0.2f, 0.3f, 0.5f, 0.8f, 1.0f};

    public Hitbox() {
        super("Hitbox", "Увеличивает или уменьшает зону попадания по существам", Category.COMBAT);
        mode = 3; // по умолчанию +0.2
    }

    @Override
    public List<String> getModes() { return List.of(NAMES); }

    /** На сколько блоков расширяется (или сужается) зона попадания с каждой стороны. */
    public float margin() {
        return VALUES[Math.max(0, Math.min(mode, VALUES.length - 1))];
    }
}
