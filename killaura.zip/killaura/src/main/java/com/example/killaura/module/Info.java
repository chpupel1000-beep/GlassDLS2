package com.example.killaura.module;

import com.example.killaura.HudLayout;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Координаты, направление и FPS. */
public class Info extends Module {
    public Info() {
        super("Info", "Координаты, направление и FPS", Category.VISUALS);
    }

    @Override
    public void renderHud(DrawContext c) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;
        int x = HudLayout.x(HudLayout.INFO, c.getScaledWindowWidth(), HudLayout.INFO.w);
        int y = HudLayout.y(HudLayout.INFO, c.getScaledWindowHeight(), HudLayout.INFO.h);
        c.fill(x, y, x + HudLayout.INFO.w, y + HudLayout.INFO.h, 0x66101826);
        String xyz = String.format("XYZ: %.0f %.0f %.0f", client.player.getX(), client.player.getY(), client.player.getZ());
        c.drawTextWithShadow(client.textRenderer, xyz, x + 5, y + 4, 0xFFF1F5F9);
        c.drawTextWithShadow(client.textRenderer, "FPS: " + client.getCurrentFps(), x + 5, y + 15, 0xFFF1F5F9);
        c.drawTextWithShadow(client.textRenderer, "Facing: " + client.player.getHorizontalFacing().asString(),
                x + 5, y + 26, 0xFFA9B4C6);
    }
}
